﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using CakeCompany.Service;







using IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((_, services) =>
        services
            .AddSingleton<IShipmentProvider, ShipmentProvider>()
            .AddSingleton<ICakeProvider, CakeProvider>()
            .AddSingleton<IOrderProvider, OrderProvider>()
            .AddSingleton<ITransportProvider, TransportProvider>()
            .AddSingleton<IOrderService, OrderService>()
            .AddSingleton<IProductionService, ProductionService>()
            .AddSingleton<IDispatchService, DispatchService>()
            )
            .Build();

BootsTrapper(host.Services);

await host.RunAsync();

static void BootsTrapper(IServiceProvider services)
{
    using IServiceScope serviceScope = services.CreateScope();
    IServiceProvider provider = serviceScope.ServiceProvider;

    IShipmentProvider shipmentProvider   = provider.GetRequiredService<IShipmentProvider>();
    shipmentProvider.GetShipment();
    Console.WriteLine("Shipment Details...");

}