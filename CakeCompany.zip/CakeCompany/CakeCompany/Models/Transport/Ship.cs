﻿namespace CakeCompany.Models.Transport;

internal class Ship
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}