﻿namespace CakeCompany.Models.Transport;

internal class Van
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}