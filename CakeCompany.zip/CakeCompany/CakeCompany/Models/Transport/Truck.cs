﻿namespace CakeCompany.Models.Transport;

internal class Truck
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}