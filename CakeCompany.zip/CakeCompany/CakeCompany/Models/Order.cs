﻿namespace CakeCompany.Models;

public record Order(string ClientName, DateTime EstimatedDeliveryTime, int Id, Cake Name, double Quantity)
{
    public DateTime EstimatedBakeTime => Name switch
    {
        Cake.Chocolate => DateTime.Now.Add(TimeSpan.FromMinutes(30)),
         Cake.RedVelvet=> DateTime.Now.Add(TimeSpan.FromMinutes(60)),
        _=> DateTime.Now.Add(TimeSpan.FromHours(15))
    };

    public PaymentIn PaymentIn => ClientName switch
    {
        string clientName when clientName.Contains("Important") => new PaymentIn
        {
            HasCreditLimit = false,
            IsSuccessful = true
        },
       _=> new PaymentIn
       {
           HasCreditLimit = true,
           IsSuccessful = true
       }

    };
}