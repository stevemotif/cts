﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Models
{
   public enum Vehical
    {
        Van,
        Truck,
        Ship
    }
}
