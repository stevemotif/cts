﻿namespace CakeCompany.Models.Cakes;

internal record RedVelvet(string CakeName);