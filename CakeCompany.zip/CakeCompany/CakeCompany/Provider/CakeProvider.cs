﻿using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;

public interface ICakeProvider
{
  
    Product Bake(Order order);
}
public class CakeProvider: ICakeProvider
{
    private readonly ILogger<CakeProvider> logger;

    public CakeProvider(ILogger<CakeProvider> logger)
    {
        this.logger=logger;
    }

    public Product Bake(Order order)
    {
        try
        {
            if (order.Name == Cake.Chocolate)
            {
                return new()
                {
                    Cake = Cake.Chocolate,
                    Id = new Guid(),
                    Quantity = order.Quantity
                };
            }

            if (order.Name == Cake.RedVelvet)
            {
                return new()
                {
                    Cake = Cake.RedVelvet,
                    Id = new Guid(),
                    Quantity = order.Quantity
                };
            }

            return new()
            {
                Cake = Cake.Vanilla,
                Id = new Guid(),
                Quantity = order.Quantity
            };
        }
        catch (Exception ex)
        {
            this.logger.LogError(ex.Message, ex);
            return new()
            {
                Cake = Cake.Vanilla,
                Id = new Guid(),
                Quantity = order.Quantity
            };
        }
    }
}