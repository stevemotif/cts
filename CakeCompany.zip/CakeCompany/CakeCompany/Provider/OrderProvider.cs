﻿using System.Reflection.Metadata.Ecma335;
using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;
public interface IOrderProvider
{
    List<Order> GetLatestOrders();
    void UpdateOrders(Order[] orders);
}
public class OrderProvider:IOrderProvider
{
    private readonly ILogger<OrderProvider> logger;

    public OrderProvider(ILogger<OrderProvider> logger)
    {
        this.logger=logger;
    }
    public List<Order> GetLatestOrders()
    {
        try
        {
            return new List<Order>
            {
            new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
            };
        }catch(Exception ex)
        {
            this.logger.LogError(ex.Message, ex);
        }
        return new List<Order>();
    }

    public void UpdateOrders(Order[] orders)
    {
    }
}


