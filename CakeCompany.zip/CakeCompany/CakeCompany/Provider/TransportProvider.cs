﻿using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;
public interface ITransportProvider
{
    Vehical CheckForAvailability(List<Product> products);
}
public class TransportProvider : ITransportProvider
{
    private readonly ILogger<TransportProvider> logger;

    public TransportProvider(ILogger<TransportProvider> logger)
    {
        this.logger=logger;
    }
    public Vehical CheckForAvailability(List<Product> products)
    {
        try
        {
            return products switch
            {
                List<Product> _products when _products.Sum(p => p.Quantity)>1000 => Vehical.Van,
                List<Product> _products when _products.Sum(p => p.Quantity) > 1000 && _products.Sum(p => p.Quantity) < 5000 => Vehical.Truck,
                _ => Vehical.Ship
            };
        }catch (Exception ex)
        {
            this.logger.LogError(ex.Message,ex);
            return Vehical.Ship;
        }
    }
    
}
