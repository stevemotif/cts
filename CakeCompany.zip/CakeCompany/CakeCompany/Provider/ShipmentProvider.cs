﻿using System.Diagnostics;
using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Service;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;

public interface IShipmentProvider
{
    List<Product> GetShipment();
}
public class ShipmentProvider : IShipmentProvider
{
    private readonly ILogger<ShipmentProvider> logger;
    private readonly IOrderService orderService;
    private readonly IProductionService productionService;
    private readonly IDispatchService dispatchService;

    public ShipmentProvider(ILogger<ShipmentProvider> logger, IOrderService orderService, IProductionService productionService ,IDispatchService dispatchService )
    {
        this.logger=logger;
        this.orderService = orderService;
        this.productionService = productionService;
        this.dispatchService = dispatchService;
    }
    public List<Product> GetShipment()
    {
        var products = new List<Product>();
        try
        {
            
            var orders = this.orderService.GetValidOrders();
            if (orders.Count>0)
            {
                products=this.productionService.Process(orders);
                this.dispatchService.Dispatch(products);
            }
           
        }
        catch (Exception ex)
        {
            logger.LogError(ex.Message,ex);
        }
        return products;
    }
}
