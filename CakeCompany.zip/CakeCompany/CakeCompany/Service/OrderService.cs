﻿using CakeCompany.Models;
using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace CakeCompany.Service;
public interface IOrderService
{
    List<Order> GetValidOrders();
}
public class OrderService: IOrderService
{
    private readonly IOrderProvider orderProvider;
    private readonly ILogger<OrderService> logger;

    public OrderService(IOrderProvider orderProvider,ILogger<OrderService> logger)
    {
        this.orderProvider = orderProvider;
        this.logger=logger;
    }
   public List<Order> GetValidOrders()
    {
        try
        {
            var orders = this.orderProvider.GetLatestOrders();
            if (!orders.Any())
                return new List<Order>();
            else
                return orders.Where(x => x.EstimatedBakeTime > x.EstimatedDeliveryTime && x.PaymentIn.IsSuccessful == true).ToList();
        }
        catch (Exception ex)
        {
            logger.LogError(ex.Message, ex);
            return new List<Order>();
        }
    }

    
}