﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Service
{
    public interface IDispatchService
    {
        bool Dispatch(List<Product> products);
    }
    public class DispatchService : IDispatchService
    {
        private readonly ITransportProvider transportProvider;

        public DispatchService(ITransportProvider transportProvider)
        {
            this.transportProvider = transportProvider;
        }
        public bool Dispatch(List<Product> products) => this.transportProvider.CheckForAvailability(products) switch
        {
            Vehical.Van => new Van().Deliver(products),
            Vehical.Truck => new Truck().Deliver(products),
            _ => new Ship().Deliver(products)
        };



    }
}
