﻿using CakeCompany.Models;
using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Service
{
    public interface IProductionService
    {
        List<Product>   Process(List<Order> orders);
    }
    public class ProductionService: IProductionService
    {
        private readonly ICakeProvider cakeProvider;
        private readonly ILogger logger;

        public ProductionService(ICakeProvider cakeProvider,ILogger<ProductionService> logger)
        {
            this.cakeProvider = cakeProvider;
            this.logger=logger;
        }

        public List<Product> Process(List<Order> orders )
        {
            var products= new List<Product>();
            try
            {
                products = new List<Product>();
                foreach (var order in orders)
                {
                    var product = cakeProvider.Bake(order);
                    products.Add(product);
                }
            }catch (Exception ex)
            {
                this.logger.LogError(ex.Message, ex);
            }
            return products;
        }
    }
}
