﻿using CakeCompany.Models;
using CakeCompany.Provider;
using CakeCompany.Service;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.UnitTest
{
    public class TestShipment
    {

        private Mock<IDispatchService> dispacherService;
        private Mock<IOrderService> orderService;
        private Mock<IProductionService> productionService;
        public TestShipment()
        {
            this.dispacherService = new Mock<IDispatchService>();
            this.orderService = new Mock<IOrderService>();
            this.productionService = new Mock<IProductionService>();

        }


        [Test]
        public void GetShipmentWithValidOrders()
        {
            try
            {
                this.orderService.Setup(x => x.GetValidOrders()).Returns(new List<Order>
            {
                new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
            });

                this.productionService.Setup(x => x.Process(It.IsAny<List<Order>>())).Returns(new List<Product>()
            {
                new Product()
                {
                     Cake = Cake.Chocolate,
                    Id = new Guid(),
                    Quantity = 1
                },
                 new Product()
                {
                     Cake = Cake.RedVelvet,
                    Id = new Guid(),
                    Quantity = 2
                },

            });

                this.dispacherService.Setup(x => x.Dispatch(It.IsAny<List<Product>>())).Returns(true);

                var _shipmentProvider = new ShipmentProvider(It.IsAny<ILogger<ShipmentProvider>>(), this.orderService.Object, this.productionService.Object, this.dispacherService.Object);
                var shippedProducts = _shipmentProvider.GetShipment();
                Assert.IsTrue(shippedProducts.Count() > 0);
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Test]
        public void GetShipmentWithInvalidOrders()
        {
            try
            {
                //this.orderProvider.Setup(x => x.GetLatestOrders()).Returns(
                this.orderService.Setup(x => x.GetValidOrders()).Returns(new List<Order>());

                this.productionService.Setup(x => x.Process(It.IsAny<List<Order>>())).Returns(new List<Product>());

                this.dispacherService.Setup(x => x.Dispatch(It.IsAny<List<Product>>())).Returns(true);

                var _shipmentProvider = new ShipmentProvider(It.IsAny<ILogger<ShipmentProvider>>(), this.orderService.Object, this.productionService.Object, this.dispacherService.Object);
                var shippedProducts = _shipmentProvider.GetShipment();
                Assert.IsTrue(shippedProducts.Count == 0);
            }
            catch (Exception)
            {

                throw;
            }

        }

        [Test]
        public void GetShipmentWithValidOrdersButCakeProviderIssue()
        {

            try
            {

                this.orderService.Setup(x => x.GetValidOrders()).Returns(new List<Order>
            {
                new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
            });

                this.productionService.Setup(x => x.Process(It.IsAny<List<Order>>())).Returns(new List<Product>());

                this.dispacherService.Setup(x => x.Dispatch(It.IsAny<List<Product>>())).Returns(true);

                var _shipmentProvider = new ShipmentProvider(It.IsAny<ILogger<ShipmentProvider>>(), this.orderService.Object, this.productionService.Object, this.dispacherService.Object);
                var shippedProducts = _shipmentProvider.GetShipment();
                Assert.IsTrue(shippedProducts.Count == 0);
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
